#include <stdio.h>
#include <stdlib.h>
#include "clase23.h"

int main()
{
    Persona** lista;
    int size;
    int index;
    int edadAux;
    char nombreAux[20];
    char preguntarSalir='n';
    persona_initLista(lista,&size,&index);

    do
    {
        Persona* persona = persona_newPersona();

        preguntarNombre(nombreAux);
        if(persona_setName(persona,nombreAux))
            printf("El nombre no es valido");
        edadAux = preguntarEdad();
        if(persona_setEdad(persona,edadAux))
            printf("La edad no es v�lida");
        persona_addPersona(persona,lista,&index,&size);
        printf("desea salir?[s|n]");
        scanf("%c",&preguntarSalir);
        preguntarSalir=tolower(preguntarSalir);
    }
    while(preguntarSalir!='s');
    return 0;
}
