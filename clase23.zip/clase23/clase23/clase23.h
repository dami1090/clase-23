


typedef struct
{
    int edad;
    char nombre[20];
} Persona;

void persona_initLista(Persona** lista,int*,int*);
void persona_addPersona(Persona* p,Persona** lista,int*,int*);
void preguntarNombre(char);
int preguntarEdad();

char* persona_getNombre(Persona* pPersona);
int persona_getEdad(Persona* pPersona);
void persona_toString(Persona* pPersona);
int persona_setName(Persona* pPersona, char* pName);
int persona_setEdad(Persona* pPersona, int edad);
Persona* persona_newPersona(void);
