#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "clase23.h"

Persona* persona_newPersona(void)
{
    Persona* persona = (Persona*)malloc(sizeof(Persona));
    return persona;
}

void persona_initLista(Persona** lista,int* size,int* index)
{
    *size = 10;
    *index=0;
    lista = (Persona**)malloc(sizeof(Persona*)*(*size));
}

void persona_addPersona(Persona* p,Persona** lista,int* index, int* size)
{
    int aux;
    aux=*index;
    lista[aux]=p;
    (*index)++;
    if((*index)>=(*size))
    {
        printf("no hay mas lugar, redefinimos el array\r\n");
        *size=(*size)+10;
        lista = (Persona**)realloc(lista,sizeof(Persona*)*(*size));
    }
}

int persona_setEdad(Persona* pPersona, int edad)
{
    if(edad>0)
    {
        pPersona->edad = edad;
        return 0; // OK
    }
    return 1; // error
}

int persona_setName(Persona* pPersona, char* pName)
{
    if(strlen(pName)>3)
    {
        strcpy(pPersona->nombre,pName);
        return 0;
    }
    return 1;
}

void preguntarNombre(char nombre)
{
    printf("ingrese nombre\n");
    setbuf(stdin,NULL);
    scanf("%[^\n]",nombre);
}

int preguntarEdad()
{
    int edad;
    printf("ingrese edad:\n");
    scanf("%d",&edad);
    return edad;
}
